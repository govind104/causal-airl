import os
import argparse
import numpy as np
import matplotlib.pyplot as plt


def plot_cartpole_reward_maps(reward_dict, dims=(0, 2), resolution=100, state_bounds=None, save_path=None, title_prefix=""):
    """
    Plot 2D reward maps over selected CartPole state dimensions.
    dims: tuple of 2 ints ∈ [0,1,2,3] — e.g., (0,2) = x vs theta
    reward_dict: key → 2D reward map numpy array
    """
    state_bounds = state_bounds or [[-2.4, 2.4], [-2, 2], [-0.42, 0.42], [-3.5, 3.5]]
    xdim, ydim = dims
    x = np.linspace(state_bounds[xdim][0], state_bounds[xdim][1], resolution)
    y = np.linspace(state_bounds[ydim][0], state_bounds[ydim][1], resolution)
    X, Y = np.meshgrid(x, y)

    fig, axes = plt.subplots(1, len(reward_dict), figsize=(6 * len(reward_dict), 5))
    if len(reward_dict) == 1:
        axes = [axes]

    for ax, (name, reward_map) in zip(axes, reward_dict.items()):
        if reward_map.shape != X.shape:
            raise ValueError(f"Reward map shape {reward_map.shape} does not match grid {X.shape}")
        im = ax.contourf(X, Y, reward_map, cmap="viridis")
        fig.colorbar(im, ax=ax)
        ax.set_title(f"{title_prefix} {name}")
        ax.set_xlabel(f"State dim {xdim}")
        ax.set_ylabel(f"State dim {ydim}")

    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300)
        print(f"[Saved] {save_path}")
    plt.close()


def load_cartpole_reward_maps(run_dir, dims=(0, 2), resolution=100):
    """
    Load learned reward maps (assumed already sliced to 2D).
    If raw 1D reward vector is found, reshape it to square grid.
    """
    reward_files = {
        "learned": "learned_reward.npy",
        "invariant": "invariant_reward.npy",
        "causal": "causal_reward.npy"
    }
    rewards_loaded = {}
    for key, fname in reward_files.items():
        path = os.path.join(run_dir, fname)
        if os.path.exists(path):
            reward = np.load(path)
            if reward.ndim == 2:
                # Already in image form
                rewards_loaded[key] = reward
            elif reward.ndim == 1:
                # Flattened — assume 2D layout
                side = int(np.sqrt(len(reward)))
                rewards_loaded[key] = reward.reshape((side, side))
            else:
                print(f"[Warning] Unexpected reward shape for {key}: {reward.shape}")
    if not rewards_loaded:
        raise FileNotFoundError(f"No reward files found in {run_dir}")
    return rewards_loaded

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plot AIRL/CausalAIRL reward heatmaps for CartPole")
    parser.add_argument("--run_dir", type=str, required=True, help="Experiment output directory")
    parser.add_argument("--save_path", type=str, required=True, help="Path to save figure")
    parser.add_argument("--dims", type=str, default="0,2", help="Which state dims to slice on (comma-separated, e.g. 0,2)")
    parser.add_argument("--title", type=str, default="")
    args = parser.parse_args()

    try:
        dims = tuple(int(i) for i in args.dims.split(","))
        assert len(dims) == 2 and all(0 <= d < 4 for d in dims)
    except:
        raise ValueError("Invalid --dims argument. Must be two comma-separated integers in [0,1,2,3], e.g. 0,2")
    reward_maps = load_cartpole_reward_maps(args.run_dir, dims=dims)
    plot_cartpole_reward_maps(reward_maps, dims=dims, save_path=args.save_path, title_prefix=args.title)